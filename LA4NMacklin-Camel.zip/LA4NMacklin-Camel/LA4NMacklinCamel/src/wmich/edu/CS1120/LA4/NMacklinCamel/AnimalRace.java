package wmich.edu.CS1120.LA4.NMacklinCamel;

import java.io.IOException;
/**
 * 
 * @author Neil Macklin-Camel
 *
 */
//This is the AnimalRace class
public class AnimalRace {
/**
 * 
 * @param args
 * @throws IOException
 * 
 */
	public static void main(String[] args) throws IOException {
		Race r = new Race(10);
		r.createRace(20,10);
		r.advanceWholeRace();
		r.print();
	} //end of main method

} // end of AnimalRace class
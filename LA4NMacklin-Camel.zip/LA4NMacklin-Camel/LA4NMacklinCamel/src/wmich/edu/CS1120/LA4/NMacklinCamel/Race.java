package wmich.edu.CS1120.LA4.NMacklinCamel;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
//This is the Race class
public class Race implements IRace{
	// This class implements the IRace interface.
			
	private ArrayList<String> name;
	private ArrayList<Character> animal;
	private ArrayList<Integer> speed;
	private ArrayList<Integer> currentSpeed;
	private ArrayList<Integer> currentPos;
	private char[] racetrack;
	
	/**
	 * 
	 * @param number of racers 
	 * 
	 */
	// Constructor: Accepts one parameter: the number of racers (int). Initialize currentPos, 
	//	fill currentPos with zeros to account for every racer starting at position zero 
	//	call the readFile method, and copy the speed ArrayList to currentSpeed.
	public Race (int numRacers) {
		currentPos = new ArrayList<Integer>();
		for (int i=0;i<numRacers;i++) {
			currentPos.add(0);
		}
		readFile();
		currentSpeed = new ArrayList<Integer>(speed);
	} //end of Race constructor
	
	// Methods: ----------------------------------------------------------------------------

	@Override
	public char[] getRacetrack() {
		return this.racetrack;
	}

	@Override
	public String getRacerName(int racerIndex) {
		return name.get(racerIndex);
	}
	
	@Override
	public int getRacerPosition(int racerIndex) {
		return currentPos.get(racerIndex);
	}
	
	/**
	 * 
	 * @param racer's index
	 * @return true or false based on if a racer is at the finish line
	 * 
	 */
	// Method getRacerIsWinner: Take one parameter: racerIndex (int). Check if the current 
	// 	position of the racerIndex has won. Return true if the racer has won and return false if
	// 	the racer has not won.
	@Override
	public boolean getRacerIsWinner(int racerIndex) {
		if (currentPos.get(racerIndex) >= racetrack.length-1) {
			// If a racer has won, then set their current position on the racetrack to the spot of the 
			// 	finish line for printing uses.
			currentPos.set(racerIndex, racetrack.length);
			return true;
		} else {
			return false;
		}
	} // end of getRacerIsWinner method
	
	/**
	 * 
	 * @param length of track
	 * @param number of racers 
	 * @throws IOException
	 * 
	 */
	// Method createRace: Initialize racetrack with the size of the parameter length. Use a Random 
	// 	object to generate a number between 0 and 3. Do this length amount of times and if a 
	// 	zero is generated, then an open plain terrain is added to racetrack, if a one is 
	// 	generated, then a forest terrain is added to racetrack, if a two is generated, then a 
	//	desert is added to racetrack, and lastly, if a 3 is generated, then a lake is added to 
	// 	racetrack. The last spot of racetrack will always be a finish line.
	@Override
	public void createRace(int length, int numRacers) throws IOException {
		racetrack = new char[length];
		Random r = new Random();
		int rand;
		for (int i = 0; i < length - 1; i++) {
			rand = r.nextInt(4); 
			switch (rand) { 
			case 0: 
				racetrack[i] = '.'; 
				break;//open plains 
			case 1: 
				racetrack[i] = '#'; 
				break;//forest 
			case 2: 
				racetrack[i] = 'O'; 
				break;//desert 
			case 3: 
				racetrack[i] = '~'; 
				break;//lake 
			} 
		} 
		racetrack[length-1] = '|';//finish line
	} // end of createRace method
	
	// Method advanceOneTurn: Instantiate an Ostrich object. Instantiate a Turtle object. 
	//	 Set currentSpeed to output of the randomSpeed method for each racer. Choose if 
	//	each racer will move their position on the racetrack by calling the currentSpeed method 
	// 	in either the Ostrich class or the Turtle class depending on which animal the racer is. 
	@Override
	public void advanceOneTurn() {
		Ostrich callO = new Ostrich();
		Turtle callT = new Turtle();
		for (int i = 0; i < 10; i++) {
			currentSpeed.set(i, randomSpeed(i));
			if (getRacerIsWinner(i) == false) {
				if (animal.get(i) == 'O') {
					// After choosing if a racer will move their position on the 
					//	racetrack, this method check if what the currentSpeed 
					// 	method from either class is negative, if it is, then the 
					//	current position will not be moved on the racetrack and 
					// 	will stay the same.
					if (callO.currentSpeed(i, currentSpeed, racetrack, currentPos) > -1) {
						currentPos.set(i, currentPos.get(i)+1);
					}
				} else {
					if (callT.currentSpeed(i, currentSpeed, racetrack, currentPos) > -1) {
						currentPos.set(i, currentPos.get(i) + 1);
					} 
				}
			}
		}
	} // end of advanceOneTurn method
	
	/**
	 * 
	 * @param index of the current racer
	 * @return a random speed between 1 and the max speed of the current racer
	 * 
	 */
	// Method randomSpeed: Takes one parameter that is the counter (int) that is used in the 
	// 	advanceOneTurn method. Creates a Random object. Generates a random integer from 
	// 	one to max speed of the racer. Returns the random integer to the advanceOneTurn 
	//	method.
	public int randomSpeed(int index) {
		Random r = new Random();
		int random = speed.get(index);
		int rand = r.nextInt(random) + 1;
		return rand;
	} // end of randomSpeed method
	
	// Method readFile: Initialize the fields: animal, speed, and name. Create a 
	// 	FileInputStream object and a DataInputStream object. Read a character into the 
	//	animal ArrayList, an integer into the speed ArrayList, and a String into the name 
	//	ArrayList until the end of the binary file.
	public void readFile() {
		animal = new ArrayList<Character>();
		speed = new ArrayList<Integer>();
		name = new ArrayList<String>();
		boolean end = false;
		try {
			FileInputStream fStream = new FileInputStream("Animal.dat");
			DataInputStream input = new DataInputStream(fStream);
			while(!end) {
				animal.add(input.readChar());
				speed.add(input.readInt());
				name.add(input.readUTF());
			}
			input.close();
		} catch (EOFException e) {
			end = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
	} // end of readFile method
	
	// Method advanceWholeRace: Using a loop, call the advanceOneTurn method and then loop 
	// 	through the getRacerIsWinner method until the getRacerIsWinner method returns true, 
	//	which means that a racer has won.
	public void advanceWholeRace () {
		boolean stop = false;
		while (!stop) {
			advanceOneTurn();
			for (int i = 0; i < 10; i++) {
				if (getRacerIsWinner(i) == true) {
					// When this method finds a winner then this method ends.
					stop = true;
					
				}
			}
		}
	} // end of advanceWholeRace method
	
	// Method print: Print the type of animals, the names of animals, the serial numbers of the 
	//	animals, and the position of the animals on the racetrack along with the entire 
	//	racetrack for each racer. Then print each the winning racer�s names.
	public void print() {
		//printing of the animal, name, serial number, and racetrack position
		for (int i = 0; i < 10; i++) {
			if (animal.get(i) == 'O') {
				System.out.print("Ostrich ");
			} else {
				System.out.print("Turtle ");
			} 
			System.out.printf("(" + getRacerName(i) + ") %d" + ":	",i+1);
			int count = 1;
			for (int j = 0; j < racetrack.length; j++) {
				if (getRacerPosition(i) == count) {
					System.out.printf("<%c>",racetrack[j]);
					count++;
				} else {
					System.out.printf(" %c ",racetrack[j]);
					count++;
				}
			}
			System.out.println();
		}
		//printing of the winner(s)
		System.out.println("\nWinner(s):");
		for (int i = 0; i < 10; i++) {
			if (getRacerIsWinner(i) == true) {
				System.out.println(getRacerName(i));
			}
		}
	} // end of print method
	
} // end of Race class

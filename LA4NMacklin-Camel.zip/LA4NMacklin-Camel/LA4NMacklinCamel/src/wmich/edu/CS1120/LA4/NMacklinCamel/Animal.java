package wmich.edu.CS1120.LA4.NMacklinCamel;

import java.util.ArrayList;

//This is the Animal class
public abstract class Animal {
	// This class is an abstract class.
		// This class is extended by the Ostrich class and the Turtle class.
	

	// An abstract method that takes an index (int), the speed or amount of movement points all 
	//	 the animals have (ArrayList<Integer>), the racetrack (character array), and the position 
	// 	 on the racetrack of all the animals(ArrayList<Integer>).
	public abstract int currentSpeed(int index, ArrayList<Integer> currentSpeed, char[] raceTrack, ArrayList<Integer> currentPos);
		
} // end of Animal class


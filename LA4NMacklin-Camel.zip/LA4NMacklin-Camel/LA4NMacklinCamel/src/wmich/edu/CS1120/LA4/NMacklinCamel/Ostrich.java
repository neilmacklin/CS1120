package wmich.edu.CS1120.LA4.NMacklinCamel;

import java.util.ArrayList;
// This is the Ostrich class
public class Ostrich extends Animal{
	// This class extends the Animal class.
	/**
	 * @param index of the current racer
	 * @param current speed ArrayList racers
	 * @param racetrack 
	 * @param current positions of the racers
	 * @return current speed of the current racer
	 *  
	 */
	// Method currentSpeed: Takes four parameters: index (int), currentSpeed (ArrayList<Integer>), 
	// 	racetrack (character array), currentPos (ArrayList<Integer>). Compare racetrack terrains 
	//	to see which terrain is next, how many currentSpeed movement points a racer will lose 
	//	or gain, then return the currentSpeed of the racer.
	@Override
	public int currentSpeed(int index, ArrayList<Integer> currentSpeed, char[] raceTrack, ArrayList<Integer> currentPos) {
		int returned = currentSpeed.get(index);
		if (currentPos.get(index) == 19) {
			returned = -1;
		} else {
			// If the next terrain matches the current one, then currentSpeed of the racer 
			//	will lose one.
			if (raceTrack[currentPos.get(index)+1] == raceTrack[index]) {
				returned = currentSpeed.get(index) - 1;
			// If the next terrain is a forest, then the currentSpeed of the racer will lose 
			//	three. 
			} else if (raceTrack[currentPos.get(index)+1] == '#') {
				returned = currentSpeed.get(index)-3;
			// If the next terrain is a lake, then the currentSpeed of the racer will lose two. 	
			} else if (raceTrack[currentPos.get(index)+1] == '~') {
				returned = currentSpeed.get(index)-2;
			// If the next terrain is an open plain, then the currentSpeed of the racer will 
			//	gain one.
			} else if (raceTrack[currentPos.get(index)] == '.') {
				returned = currentSpeed.get(index)+1;
			// If the next terrain is a desert, then the currentSpeed of the racer will gain 
			//	one.
			} else if (raceTrack[currentPos.get(index)] == 'O') {
				returned = currentSpeed.get(index)+1;
			} 
		}
		// If the returned value is negative the advanceOneTurn method in the Race 
		//	class will check for this. 

		return returned;
	} //end of the currentSpeed method

} // end of Ostrich class
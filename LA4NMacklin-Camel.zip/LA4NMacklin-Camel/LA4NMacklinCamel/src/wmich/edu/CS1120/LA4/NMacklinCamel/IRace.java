package wmich.edu.CS1120.LA4.NMacklinCamel;

import java.io.IOException;

public interface IRace {
	    //returns an array of characters, representing the racetrack
		char[] getRacetrack();
		//Returns the name of the racer with the given index
		String getRacerName(int racerIndex);
		//Returns the position of the racer with the given index
		int getRacerPosition(int racerIndex);
		//Returns whether or not the racer with the given index is a winner (crossed the finish line)
		boolean getRacerIsWinner(int racerIndex);
		//Creates the racetrack of a given length and instantiates the specified number of racers
		//Racetrack should be a random racetrack using the four different types of terrain, and ending
		//with the finish line.
		void createRace(int length, int numRacers) throws IOException;
		//Causes each racer to take one turn, moving a number of spaces based on their
		// movement speed and the terrain
		void advanceOneTurn();
		
}

package wmich.edu.CS1120.LA5.NMacklinCamelCharlesDNoble;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PostfixMain extends JFrame{
	private JLabel messageLabel;
	private JPanel panel;
	private JButton button1;
	private JButton button2;
	private JButton button3;
	private final int WINDOW_HEIGHT = 200;
	private final int WINDOW_WIDTH = 350;
	
	public PostfixMain() {
		//title at top of box
		setTitle("PostFix Expressions");
		//size of box
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		//exit when click 'X'
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildPanel();
		add(panel);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	private void buildPanel() {
		panel = new JPanel();
		messageLabel = new JLabel("Click a button to selct a file to process.");
		button1 = new JButton("Process Expression1.dat");
		button2 = new JButton("Process Expression2.dat");
		button3 = new JButton("Process Expression3.dat");
		button1.addActionListener(new ActionListener() {
		    public void actionPerformed(java.awt.event.ActionEvent e) {
		    	if(e.getActionCommand().equals("Process Expression1.dat")){
		    		Decoder decoder= new Decoder();
		    		decoder.processExpressions("Expression1.dat");
		    		}
		    }
		});
		button2.addActionListener(new ActionListener() {
		    public void actionPerformed(java.awt.event.ActionEvent e) {
		    	if(e.getActionCommand().equals("Process Expression2.dat")){
		    		Decoder decoder= new Decoder();
		    		decoder.processExpressions("Expression2.dat");
		    		}
		    }
		});
		button3.addActionListener(new ActionListener() {
		    public void actionPerformed(java.awt.event.ActionEvent e) {
		    	if(e.getActionCommand().equals("Process Expression3.dat")){
		    		Decoder decoder= new Decoder();
		    		decoder.processExpressions("Expression3.dat");
		    		}
		    }
		});
		panel.add(messageLabel).setForeground(Color.BLACK);
		panel.setBackground(Color.CYAN);
		button1.setForeground(Color.WHITE);
		button2.setForeground(Color.WHITE);
		button3.setForeground(Color.WHITE);
		panel.add(button1).setBackground(Color.BLUE);
		panel.add(button2).setBackground(Color.BLUE);
		panel.add(button3).setBackground(Color.BLUE);
	}
	
	public static void main(String[] args) {
		new PostfixMain();
	}
	
}
